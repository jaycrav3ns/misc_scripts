const emojiLinks = document.querySelectorAll('.emoji-link');
const checkmarkContainer = document.getElementById('checkmarkContainer');

emojiLinks.forEach(link => {
  link.addEventListener('click', function (event) {
event.preventDefault(); // Prevent the default link behavior
const emoji = this.textContent; // Get the emoji from the clicked link
copyEmoji(emoji); // Call the copyEmoji function
  });
});

function copyEmoji(emoji) {
  const emojiInput = document.getElementById('emojiInput');
  emojiInput.value = emoji;
  emojiInput.select();
  document.execCommand('copy');

  const copiedMessage = document.getElementById('copiedMessage');

  // Show the checkmark
  checkmarkContainer.style.display = 'block';

  // Set a timer to hide the checkmark after 2 seconds (2000 milliseconds)
  setTimeout(() => {
// Hide the checkmark
checkmarkContainer.style.display = 'none';
  }, 2000);
}
