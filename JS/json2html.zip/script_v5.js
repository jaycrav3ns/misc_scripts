const fs = require('fs');
const dirtyJSON = require('dirty-json');
const Handlebars = require('handlebars');
const escapeJSON = require('escape-json-node');

// Read the JSON file
fs.readFile('x02_cmp.json', 'utf8', (err, jsonString) => {
  if (err) {
    console.log('Error reading file:', err);
    return;
  }

  // Check if the input is a string
  if (typeof jsonString !== 'string') {
    console.log('Input is not a string.');
    return;
  }

  // Escape invalid characters
  const escapedJSON = escapeJSON(jsonString);

  // Parse the JSON data with dirty-json
  try {
    const jsonData = dirtyJSON.parse(escapedJSON);

    // Read the HTML template file
    fs.readFile('template.hbs', 'utf8', (err, htmlString) => {
      if (err) {
        console.log('Error reading file:', err);
        return;
      }

      // Compile the template
      const template = Handlebars.compile(htmlString);

      // Render the template with the JSON data
      const html = template(jsonData);

      // Write the HTML to a file
      fs.writeFile('output3.html', html, (err) => {
        if (err) {
          console.log('Error writing file:', err);
          return;
        }
        console.log('HTML file written successfully.');
      });
    });
  } catch (err) {
    console.log('Error parsing JSON data:', err);
    return;
  }
});
