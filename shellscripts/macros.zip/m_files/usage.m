if [ $# -eq 0 ]; then
    >&2 echo "Usage: $(basename $0) [OPTIONS] [FILE]"
    exit 1
fi
