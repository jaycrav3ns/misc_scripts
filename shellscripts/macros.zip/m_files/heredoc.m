cat <<EOF

Here
Document

EOF
