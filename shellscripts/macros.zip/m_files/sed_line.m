grab_line=$(sed '2q;d' file.txt) 
