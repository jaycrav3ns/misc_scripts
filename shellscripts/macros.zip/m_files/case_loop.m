#!/bin/bash

while true; do
  read -p "Choose an option (a, b, q): " option
  case ${option} in
    a)
      echo "Running commands from choice A."
      ;;
    b)
      echo "Running commands from choice B."
      ;;
    q)
      echo "Quit."
      break
      ;;
    *)
      echo "Invalid option."
      ;;
  esac
done
