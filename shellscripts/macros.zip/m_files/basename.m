base_name="${file_input%.*}"
