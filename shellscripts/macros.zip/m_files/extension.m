extension="${file_input##*.}"
