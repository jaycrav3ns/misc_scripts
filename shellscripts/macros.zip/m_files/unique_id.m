unique_id=$(tr -dc 'a-zA-Z0-9_-' < /dev/urandom | fold -w 6 | head -n 1)
