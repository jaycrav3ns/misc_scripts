﻿if cmd
then cmd
elif cmd # optional
then cmd
else cmd # optional
fi
