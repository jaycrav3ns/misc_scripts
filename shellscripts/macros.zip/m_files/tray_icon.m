yad --notification --skip-taskbar --image="starred" --text="Always On Top!" \
    --command="bash -c 'yad --about'" \
    --menu=" Option 1 !bash -c '1.sh' \
    | Option 2 !bash -c '2.sh' \
    | Exit !exit 0 \
