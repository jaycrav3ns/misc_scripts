for file in ./*.mp3; do name="${file%.*}"; ffmpeg -i "$file" "$name".wav; done
