[[ -e FILE ]] 	Exists      [[ -r FILE ]] 	Readable
[[ -h FILE ]] 	Symlink     [[ -d FILE ]] 	Directory
[[ -w FILE ]] 	Writable    [[ -s FILE ]] 	Size is > 0 bytes
[[ -f FILE ]] 	File        [[ -x FILE ]] 	Executable
[[ FILE1 -nt FILE2 ]] 	1 is more recent than 2
[[ FILE1 -ot FILE2 ]] 	2 is more recent than 1
[[ FILE1 -ef FILE2 ]] 	Same Files
[[ -z STRING ]] 	Empty       [[ -n STRING ]] 	Not Empty
[[ STRING == STRING ]] 	Equal [[ STRING != STRING ]] 	Not Equal
[[ NUM -eq NUM ]] 	Equal     [[ NUM -ne NUM ]] 	Not Equal
[[ NUM -lt NUM ]] 	Less      [[ NUM -le NUM ]] 	Less or Equal
[[ NUM -gt NUM ]] 	Greater   [[ NUM -ge NUM ]] 	Greater or Equal

[[ STRING =~ STRING ]] 	Regular Exp
(( NUM < NUM )) 	Numeric Conditions

[[ -o noclobber ]] 	If OPTIONNAME is enabled
[[ ! EXPR ]] 	Not   [[ X && Y ]] 	And   [[ X || Y ]] 	Or
