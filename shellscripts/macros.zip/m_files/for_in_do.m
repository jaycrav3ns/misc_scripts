for item in *.file; do

done
