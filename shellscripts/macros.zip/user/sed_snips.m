Remove only lines 1 and 9:
sed -i '1d;9d' file.txt

Remove line 1 through 9:
sed -i '1,9d' file.txt

Remove the last line:
sed -i '$d' file.txt

Remove lines containing 'string':
sed -i '/string/d' file.txt

Remove all empty lines:
sed -i '/^$/d' file.txt
