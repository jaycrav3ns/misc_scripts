Save as: `file.sh`<br>
Change mode executable: `chmod +x file.sh`<br>
Usage: `./file.sh`
