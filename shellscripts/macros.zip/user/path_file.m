﻿dir -1 | xargs -I {} echo "$PWD/{}"
