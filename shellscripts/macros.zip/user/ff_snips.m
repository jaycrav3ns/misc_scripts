ffmpeg -hide_banner -i -c copy

-pix_fmt yuv420p

-c:a aac

-c:v libx264 -crf 23

-avoid_negative_ts auto
-avoid_negative_ts make_zero

