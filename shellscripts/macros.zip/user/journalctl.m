Show  the end of the previous boot's logs:
sudo journalctl -b -1 -e
