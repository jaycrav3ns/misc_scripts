Use `h, j, k, l` to move `left, down, up, and right`

Use `gg` to go to the top of the file and `G` to go to the bottom.

Press `i` to enter insert mode for editing text.

Press `Esc` to return to normal mode.

To save, type :w and press Enter

To exit, type :q

To save and exit, type :wq

Use `u` to undo and `trl + r` to redo changes.

