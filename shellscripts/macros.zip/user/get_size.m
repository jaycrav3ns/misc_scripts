﻿file_size_kb=`du -k "$filename" | cut -f1`

stat --printf="%s" "$filename"

adds the filename and indent the output:
wc -c "$filename" | awk '{print $1}'

prevent filename:
wc -c < "$filename"

size="$(wc -c <"$filename")"

find -- "$file" -prune -printf '%s\n'    # st_size of file
find -L -- "$file" -prune -printf '%s\n' # after symlink resolution
