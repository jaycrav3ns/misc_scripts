#!/bin/bash

source=$(realpath "$0")
source=$(dirname "$source")

help_output() {
		clear -x
    >&2 echo "macro's for bash. usage: mac [name]"
    echo " she    shebang!        ckret   check return        asc     asc. array"
    echo " case   loop (a, b, c)  sedln   sed line num.       date    date/time"
    echo " base   basename        here    here doc            ifte    if then else" 
    echo " ext    extension       tray    yad tray icon       forin   for in.. do"
    echo " use    usage           incli   input (or: ingui)   unid    unique id"
		echo " ckcmd  check exists"
    echo
    echo " gui   usage: mac [name] gui (no cursor output)"
    echo " more  show custom macro's"
    echo " help  shows this text"
    exit 1
}

gui_box() {
    Xdialog --title "Macro GUI" --allow-close --center --no-buttons --left --textbox "$1" 20 50
}

type_at_cursor() {
    sleep 2
    while IFS= read -r line; do
        xdotool type --delay 1 -- "$line"
        xdotool key Return
    done < "$1"
}

if [ $# -eq 0 ]; then
    help_output
fi

input="$1"
arg="$2"

case "$input" in
    help)
        help_output
        ;;
    more)
        echo "custom macro list:"
        echo "  requires '.m' (e.g. mac path_and_file.m gui)"
        ls -1v "$source/user"
        exit 1
        ;;
    *)
        declare -A macros
        macros=(
						["she"]="m_files/shebang.m"
						["case"]="m_files/case_loop.m"
						["base"]="m_files/basename.m"
						["ext"]="m_files/extension.m"
						["use"]="m_files/usage.m"
						["ckret"]="m_files/check_return.m"
						["sedln"]="m_files/sed_line.m"
						["here"]="m_files/heredoc.m"
						["tray"]="m_files/tray_icon.m"
						["incli"]="m_files/user_input_cli.m"
						["ingui"]="m_files/user_input_gui.m"
						["asc"]="m_files/asc_array.m"
						["date"]="m_files/date_entry.m"
						["ifte"]="m_files/if_then_else.m"
						["forin"]="m_files/for_in_do.m"
						["unid"]="m_files/unique_id.m"
						["ckcmd"]="m_files/check_cmd.m"
				)

        if [[ ${macros[$input]} ]]; then
            input=${macros[$input]}
						input=$(echo "$source/$input")
        else
            if [[ -f "$source/user/$input" ]]; then
                input="$source/user/$input"
            else
                echo "Unknown macro: $input"
                exit 1
            fi
        fi

        if [[ "$arg" == "gui" ]]; then
            gui_box "$input"
        else
            type_at_cursor "$input"
        fi
        ;;
esac

exit 0
